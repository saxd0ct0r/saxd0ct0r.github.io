# Anki Card Pipeline — Tutorial Source Document
## For New Users of Anki and the Card Generation Pipeline
### Draft v1.0 | Tim Owen

---

## Section 1: Why Card Quality Matters

### The Promise of Spaced Repetition

Spaced repetition is a learning method that shows you each piece of information at precisely the moment you are about to forget it. By repeatedly recalling information at increasing intervals, you move it from short-term exposure into long-term memory far more efficiently than rereading or highlighting ever could.

Anki is a spaced repetition software (SRS) application. It tracks your performance on every card you study and schedules each card for review at its own optimal interval. Cards you find easy appear less frequently. Cards you find difficult appear more often. Over time, the system builds a picture of what you know and focuses your energy where it is most needed.

The method works. Studies in medicine, law, language acquisition, and academic settings confirm that spaced repetition produces durable, long-term retention at a fraction of the study time required by passive review. Medical students who use Anki consistently outperform peers on board exams. Language learners using SRS acquire and retain vocabulary faster than classroom-only students.

But there is a catch.

The method only works as well as the cards. A bad card wastes your time. A deeply bad card actively interferes with learning — it creates confusion, frustration, and false confidence. A deck full of bad cards turns a powerful learning tool into an obstacle.

### What Makes a Card Bad

There are a small number of failure modes that account for nearly every ineffective flashcard ever made.

**The kitchen-sink card.** This card asks one question but expects several facts in the answer. For example: "What is the rotator cuff?" answered with "A group of four muscles — supraspinatus, infraspinatus, teres minor, and subscapularis — that stabilize the shoulder joint and allow for rotation." Reviewing this card, you might recall three of the four muscles perfectly and still mark it wrong. Or you might mark it correct while quietly unsure about one of them. The card conflates four separate testable facts into one event. It produces noise, not signal.

**The yes/no card.** "Does the normal distribution have a mean of zero?" Answer: sometimes yes, sometimes no — it depends on whether it's standardized. More importantly, a yes/no question does not require you to retrieve anything. You can guess correctly half the time. The correct formulation is a retrieval question: "What are the parameters that define a normal distribution?" Now you must produce the answer, not merely recognize it.

**The orphan fact.** A card that tests a detail without providing any framing for what kind of detail it is. "What is 1.96?" Answer: "The z-score for a 95% confidence interval." This fact is cardable — but only for someone who already knows what a z-score is and why confidence intervals matter. For a learner encountering it cold, the number floats without context. The card needs a framing field — what domain is this from? Why does it matter?

**The context-free cloze.** A fill-in-the-blank card where the surrounding sentence does not give the reader enough to work from. "The _____ is responsible for external rotation of the shoulder at 0 degrees of abduction." Unless the learner already knows the concept, there is no purchase for recall. The sentence needs to include enough anatomical context that the blank can be reasoned toward, not merely guessed.

**The missed concept.** A card that asks for a peripheral detail while skipping the core concept entirely. You could have a hundred cards about the specifics of a statistical test and not one card asking what the test is actually for, what question it answers, or when you would choose it over an alternative. Drilling details before establishing foundations is one of the most common self-study mistakes.

### What Makes a Card Work

A good card is atomic — it tests one fact, and one fact only. The answer is the briefest possible correct response. The question has exactly one defensible answer. The surrounding fields provide just enough context to prime recall without giving it away.

A good card also belongs to a set. No concept lives in isolation. The best decks combine overview cards ("What is the primary function of the rotator cuff?") with detail cards ("Which rotator cuff muscle inserts on the greater tubercle and initiates shoulder abduction?") and scenario cards ("An athlete presents with pain on resisted external rotation but no pain on abduction — which rotator cuff muscle is most likely involved?"). Each card type trains a different retrieval pathway.

The pipeline you are about to learn is designed to produce cards that meet these standards reliably — by giving you a structured framework for quality, a set of card types optimized for different learning tasks, and an AI assistant to do the heavy lifting of drafting, while keeping you in the role of evaluator and decision-maker.

---

## Section 2: Wozniak's Principles — The Foundation of Card Quality

### Who Is Wozniak, and Why Does It Matter?

Piotr Wozniak is the researcher who developed the first spaced repetition algorithm and built SuperMemo, the predecessor to Anki. Over decades of studying how humans retain information, he derived a set of principles for formulating knowledge that consistently produce better retention. These are not abstract theory — they are the distilled result of observing millions of cards succeed and fail.

The pipeline uses his most practically important principles as a quality checklist. You do not need to memorize all of them. You need to internalize the ones that affect card-writing decisions every day. Here are the twelve that matter most.

### Comprehension First

Never card what you do not understand. If the source text introduces a term without defining it, or explains a process without making the underlying concept clear, skip it. Carding a concept you don't understand produces blind learning — you can repeat the answer without knowing what it means, which collapses under any question phrased differently.

If you are using an AI assistant to generate cards, it will flag these gaps for you. Your job is to respond to the flag by either providing the missing context or instructing the assistant to skip the concept until you've filled in the background.

### Minimum Information Principle

The ideal card answer is the shortest possible response that uniquely identifies the correct concept. Strip everything that is not the fact being tested.

Compare these two Back fields for the same concept:

*Verbose:* "The practice of integrating security considerations throughout the software development lifecycle, rather than treating security as a final-stage review."

*Minimal:* "Integrating security throughout the development lifecycle, not as a final-stage addition."

Both are correct. The minimal version is better. The extra words don't add retrieval value — they add noise. When you review a minimal card correctly, you know you actually recalled the concept. When you review a verbose card correctly, you might have just recognized a phrase.

### Atomicity — One Card, One Fact

If forgetting any single word of the answer causes the entire answer to fail, the card has more than one testable fact. Split it.

Consider: "Name the four lobes of the cerebral cortex." Answer: "Frontal, parietal, temporal, occipital." This is actually four facts. If you forget occipital, did you fail? What did you actually learn today? The answer is ambiguous. Four atomic cards — one per lobe, tested by location or function — produce unambiguous results.

The exception is when items form a true conceptual unit that is meaningless in isolation. The three planes of anatomical motion (sagittal, coronal, transverse) are not quite atomic in this sense — knowing one without the others is knowing one-third of the framework. In that case, use a structured cloze card that presents all three as a set, which is covered in the Cloze section.

### No Yes/No Questions

Yes/no questions require recognition, not retrieval. Retrieval is the mechanism that builds memory. Reformulate every yes/no question into an open recall question.

"Does a t-test assume normally distributed data?" becomes "What distributional assumption underlies the independent samples t-test?"

"Is the supraspinatus part of the rotator cuff?" becomes "Which muscle initiates shoulder abduction and is part of the rotator cuff?"

### Holistic Before Specific

Before drilling any detail about a concept, ensure there is at least one card that captures the concept's purpose, identity, or defining function. A student who cannot answer "What is analysis of variance used for?" is not ready to retain "What is the F-ratio in ANOVA?"

The pipeline enforces this by generating foundational identity cards before attribute or detail cards within any section. When you review a new topic, the overview card arrives first.

### Context Cues Reduce Failure

Every card should signal what domain it is from, so the learner's brain can prepare the right frame before the question arrives. The pipeline uses a ContextHint field for this — a brief label like [Anatomy] or [Statistics] that appears before the question.

This is not giving away the answer. It is replicating the conditions under which knowledge is actually used. A clinician treating a shoulder injury is already in an anatomical frame of mind. A context cue primes that frame.

### Strategic Redundancy — Cover the Same Ground Multiple Ways

Key concepts should appear in more than one card type. An SA card that asks "What is the null hypothesis?" tests direct recall. A cloze card with "The null hypothesis states that there is {{c1::no statistically significant}} relationship between the variables" tests recognition within sentence context. A scenario MCQ card that presents a study result and asks whether to reject the null hypothesis tests application.

These are three different retrieval pathways for the same concept. Using all three produces more durable memory than any single type alone.

### Bidirectional Pairs for Key Terms

High-value terms deserve two SA cards: one that goes term → definition, and one that goes definition → term. If you can recall the term when given the definition, but not the definition when given the term, you haven't learned it — you've just learned to recognize it.

Not every term warrants this treatment. Reserve bidirectional pairs for core vocabulary that must be retrievable in both directions: foundational anatomical terms, key statistical concepts, and any term that will appear in multiple contexts throughout your study.

### Distinct Phrasing for Easily Confused Concepts

When two concepts are frequently confused, ensure that each card about one of them uses phrasing that cannot apply to the other. The question for Concept A must have only one defensible answer: Concept A, not Concept B.

If you are building cards on Type I and Type II errors in hypothesis testing, each card's question must be specific enough that "false positive" and "false negative" cannot be swapped without the answer being wrong. If either answer could plausibly fit either question, the cards will fight each other in memory.

### Cloze Deletions for Definitions and Sequences

Cloze cards — fill-in-the-blank — are especially effective for definitions, sequences, and enumerated lists. The full sentence provides context; the blank provides the retrieval challenge; the revealed answer confirms or corrects.

They work best when the surrounding sentence is meaningful on its own. A sentence like "The three planes of anatomical motion are the {{c1::sagittal}}, {{c1::coronal}}, and {{c1::transverse}} planes" gives the learner context, tests recognition, and reinforces the full set simultaneously.

For longer lists, overlapping windows are used: instead of one card testing all five items, three cards each test a window of three consecutive items. This keeps each card atomic while training recall of the full sequence in context.

### Avoid Vague Enumerations

Never card a list described loosely: "several types," "including but not limited to," "and other related factors." Card only complete, bounded lists. A cloze card that has an indeterminate number of correct answers teaches the learner to guess, not to recall.

### Visual and Mnemonic Anchors for Abstract Concepts

When a concept is abstract or difficult to visualize, a brief vivid scene or memory hook can significantly improve retention. The pipeline provides a VisualMnemonic field for this purpose. A simple one-sentence image — "Picture a sieve where only the right-sized particles pass through — that's selective permeability" — can be the difference between a concept that sticks and one that slides away every review cycle.

---

## Section 3: The Three Note Types

### Overview

The pipeline uses three Anki note types. Each is designed for a specific kind of learning task. Understanding what each type does — and what it requires to function correctly — is more important than memorizing field names.

### Simple Answer (SA)

**What it is.** The SA card is the classic flashcard: a question on the front, an answer on the back. In Anki terminology, it uses the Basic note type.

**When to use it.** SA cards are best for direct recall of discrete facts: definitions, names, purposes, and key relationships. "What is the function of the biceps femoris?" is an SA card. "What prefix is used for logarithmic units of sound pressure?" is an SA card.

**Key fields to know.** The Front field is the question — always an open recall prompt, never yes/no. The Back field is the answer, expressed in the fewest words that correctly convey the concept. The ContextHint field provides the domain label that appears above the question. The Explanation field holds supporting context, elaboration, or alias information that appears after the answer — it is not tested, but it enriches understanding on review.

**The cardinal rule for SA.** The Back field must be atomic. If the answer contains more than one independently forgettable fact, the card should be split or converted to a different type.

### Cloze Deletion (CD)

**What it is.** The CD card presents a complete sentence with one or more words blanked out. The learner must supply the missing word or phrase. In Anki, this uses the Cloze note type, and the blanks are marked with special notation: `{{c1::answer}}`.

**When to use it.** CD cards are best for definitions embedded in context, sequences and ordered lists, acronym expansions, and any content where the surrounding sentence provides essential framing. They test recognition within context — a complementary pathway to the direct recall SA card tests.

**Key field.** The Text field contains the complete sentence with the cloze notation. The number in `c1` determines which blanks belong to the same test event: all blanks marked `c1` blank out and reveal together. If a sentence has both a `c1` and a `c2` blank, Anki creates two separate cards from that single note — one where `c1` is blanked and `c2` is visible, and one where the reverse is true.

**Common design choices.** Overlapping windows are used for lists: rather than one card testing all five items, three cards each test a window of adjacent items, all marked `c1` within each card. For terms that would cue each other if blanked separately — like "threat" and "threat actor" — they are grouped under the same cloze number so they blank and reveal together.

**The cardinal rule for CD.** Every cloze card must be fully self-contained. No pronouns that refer to other cards ("it," "they," "the above concept"). A reader seeing only this card must be able to understand the sentence completely.

### Multiple Choice (MCQ)

**What it is.** The MCQ card presents a question with four options: one correct answer and three distractors. It uses a custom Anki note type with JavaScript that shuffles and randomizes the options on every review, preventing position-based memorization.

**When to use it.** MCQ cards are best for scenario-based application questions, classification tasks, and periodic comprehension checks. They train recognition of the correct answer among plausible alternatives — the skill tested by most certification exams.

**Why the MCQ type has special requirements.** The options are randomized by a JavaScript script embedded in the card template. This means the card must be built so the script can find what it needs: correct answers in one field, distractors in another, explanations in a third field that match the order of options. If these fields are malformed — missing entries, wrong delimiter, merged explanations — the card will display incorrectly or show nothing at all.

**Key fields and their purpose.** The Corrects field holds all correct answers, each separated by the `||` delimiter. The Distractors field holds all distractors, also `||`-delimited. The Explanation field holds one explanation per answer option, in the same order as the correct answers followed by the distractors, each also `||`-delimited. Each explanation must be a complete, standalone statement — the script may display options in any order, and not all distractors are guaranteed to appear.

**The cardinal rules for MCQ.** First: distractors must be genuinely plausible. An obviously wrong distractor teaches the learner to eliminate options by surface features, not by understanding. Second: each explanation must be self-contained and order-agnostic — never "as noted above" or "unlike the first option." Third: the question prompt must not echo the phrasing of the correct answer. If a student can identify the correct answer by matching words between the question and an option, the card is testing pattern matching, not knowledge.

**A note on multi-correct variants.** The MCQ type supports "Select 2" and "Select 3" variants for questions with multiple correct answers. These are activated by dedicated fields (`HasTwoCorrects`, `HasThreeCorrects`). When the "Select 2" variant is active, two correct answers and three distractors are drawn from the pools. The same randomization and explanation requirements apply.

---

## Section 4: The Pipeline Workflow

### What the Pipeline Is

The pipeline is a structured process for converting a block of source text into a set of Anki flashcards. It involves three participants: the source material (a textbook section, lecture notes, a document), an AI assistant (any capable large language model), and you, the human evaluator.

The AI drafts cards. You approve, revise, or reject them. The result is a set of cards that meet a quality standard you have defined through your feedback.

The pipeline is LLM-agnostic. The specific AI assistant you use does not matter — what matters is how you structure the session and how you evaluate the output.

### Before the Session: Capture

The pipeline separates capture (getting source text into a stable document) from processing (turning that text into cards). This separation protects you if a session goes sideways — your source material is safe in its document regardless of what happens in the conversation.

Capture means: take the raw text from wherever it lives and paste it verbatim into a dedicated document — a Google Doc, a text file, or any plain-text format your AI assistant can read. Do not pre-edit or summarize. Capture what is there, including headings, bullet points, and numbered lists. You will instruct the AI to extract the relevant concepts; you do not need to pre-digest the material.

Name the document to match the section it covers. This name becomes the source reference on your cards.

### Opening a Session

Each processing session covers one text block — one section, one chapter, one document. Do not pile multiple sections into a single session.

When you open a session, provide the AI assistant with:
1. The course or subject name
2. The section reference (this becomes the SourceRef on every card)
3. The target exam or learning goal
4. Any existing cards for this subject (so the AI can avoid duplicating concepts already carded)
5. The source text, either pasted directly or retrieved from your document storage

A typical session opener looks like this:

> Subject: Human Anatomy — Shoulder Girdle
> Source: Chapter 4, Section 4.3 — Rotator Cuff Muscles
> Learning goal: Physical therapy board exam
> No existing cards for this subject yet.
> [Paste source text here]

### The Evaluation Loop

The AI presents cards one at a time (or as natural pairs, such as bidirectional SA pairs). For each card, you respond with one of four actions:

**Approved.** The card is accepted as written. The AI proceeds to the next.

**Feedback.** Describe what is wrong. The AI revises and re-presents. Common feedback: "This answer has two facts — split it." "The distractors are too obvious." "The question is a yes/no — reformulate."

**Decompose.** The card is too complex. The AI breaks it into smaller atomic cards.

**Cut.** The card is low value or redundant. The AI removes it.

After each piece of feedback you approve, the AI scans remaining unapproved cards and reports whether the same issue appears elsewhere. This is called a propagation report. Review it before moving on.

### What to Check Before Approving

Before approving any card, ask yourself two questions:

*Atomicity test:* If I forgot any single word of this answer, does the whole answer fail? If yes, the answer has more than one testable fact.

*Uniqueness test:* Does this question have exactly one correct, unambiguous answer? If no, the question is too vague or the answer needs constraint.

For MCQ cards, add a third check:

*Distractor test:* Could I eliminate any of the wrong answers without knowing anything about the subject? If yes, those distractors are not doing their job.

### Finalizing a Session

When you are satisfied with the card set, signal completion: "Finalize," "Close this batch," or similar. The AI outputs three complete CSV blocks — one for Simple Answer cards, one for Cloze cards, one for Multiple Choice cards — with headers, ready to import into Anki.

After importing, update the source document's status and record the last card ID used, so the next session picks up seamlessly.

---

## Section 5: The Living Rulebook

### Why Rulings Exist

No set of instructions anticipates every situation. The first time you encounter a concept that has three legitimate names, or a list that contains seven items, or a scenario where the obvious card type is clearly wrong, you will make a decision — and that decision should be recorded.

The pipeline maintains a Ruling Log for this purpose. It is a simple document that grows over time, capturing edge case decisions and their rationale. When the same situation recurs — and it will — you can apply the established ruling consistently instead of reasoning from scratch.

### What a Ruling Looks Like

Each ruling has an ID, a date, a brief rule statement, and the situation that triggered it. For example: a ruling might establish that when a concept has three commonly used names, the most exam-relevant name goes on the card's Back field, and the other names are explained in the Explanation field. That ruling, once written, applies to every similar situation going forward.

The Ruling Log is not a bureaucratic document — it is a memory aid. It encodes lessons learned into a form that can be consulted quickly.

### Starting Your Own Ruling Log

The version of the Ruling Log included with this pipeline is a seed — a set of rulings derived from one user's experience processing one set of materials. Many of those rulings will apply directly to your work. Some will not. As you process your own material and make your own decisions, your Ruling Log will grow to reflect the specific challenges of your domain.

You can inspect the current Ruling Log to understand the kinds of situations that generate rulings. You do not need to memorize its contents. What matters is the habit: when you resolve an ambiguous situation, write it down.

### Back-Propagation — Correcting Cards After Import

Once cards are imported into Anki, they will occasionally reveal problems that were not apparent during the evaluation loop. A card that seemed clear during review may turn out to be ambiguous in practice. Two cards from different sessions may conflict with each other. A fact may need updating.

Back-propagation is the process of correcting an already-imported card. You open a new session with the AI assistant, provide the problematic card, describe the failure mode, and receive a corrected version ready to replace the original.

This is not a failure of the pipeline — it is the pipeline working as intended. The Anki scheduling system will surface problem cards through a mechanism called leeches: cards that you fail repeatedly. When a leech appears, treat it as a signal. Review the card design, not just the content.

---
*End of TUT Source Document v1.0*
*Processing note: Feed sections 1–5 into pipeline sessions in order. Each section is designed to yield approximately 4–5 SA cards, 4–5 CD cards, and 2–3 MCQ checkpoint cards, totaling roughly 55–65 cards across all five phases. The Ruling Log section (Section 5) intentionally omits specific ruling details — direct users to the actual file for those.*
